/*
 * Copyright (c) 2025 by FlashInfer team.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <string>

#include "tvm_ffi_utils.h"

void CutlassMXFP8GroupwiseMoeGEMMSM120(TensorView a, TensorView b, TensorView a_scale,
                                       TensorView b_scale, TensorView m_indptr, TensorView out,
                                       std::string scale_major_mode, int64_t scale_granularity_m,
                                       int64_t scale_granularity_n, int64_t scale_granularity_k,
                                       int64_t is_gated);

TVM_FFI_DLL_EXPORT_TYPED_FUNC(moe_gemm_mxfp8_nt_groupwise, CutlassMXFP8GroupwiseMoeGEMMSM120);
